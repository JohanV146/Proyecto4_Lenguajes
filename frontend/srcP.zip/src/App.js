import React, { useState, useEffect } from 'react';
import './ButtonStyles.css';
import Board from './Board.js';


//Cargamos la libreria io para clientes.
import {io} from 'socket.io-client';


//establecemos la conexion.
const socket = io('http://localhost:3005');

const App = () => {
  //
  const [isConnected, setIsConnected] = useState(false);
  const [showHomePage, setShowHomePage] = useState(false);
  const [gameId, setGameId] = useState(null);

  //Lista de eventos del websocket.
  useEffect(() => {
    socket.on('connect', () => setIsConnected(true));

    socket.on('message', (data) => {
        console.log(data);
    });

    return () => {
      socket.off('connect');
      socket.off('message');
    }
  }, []);

   /*
  const sendMessage = (texto) => {
    socket.emit('message', {
      usuario: socket.id,
      mensaje: texto
    });
  } */

  //Evento seleccion de botones.

  const handleButtonClick = (buttonContent) => {
    if(buttonContent === "create") {
      setGameId(30);
      setShowHomePage(!showHomePage);
    }
  };

  //funcion para enviar datos al servidor.
  /*
  const sendMessage = (texto) => {
    socket.emit('message', {
      usuario: socket.id,
      mensaje: texto
    });
  } 
  */
  return (
    <div className="button-container"> 
        {showHomePage ? (
          <Board gameId={gameId}/>
        ) : (
        <>
          <h2> {isConnected ? 'Conectado': 'No conectado'} </h2>
          <button className="button" onClick={() => handleButtonClick("create")}>
            Crear partida
          </button>
          <button className="button" onClick={() => handleButtonClick("Jugar")}>
            Jugar
          </button>
          <button className="button" onClick={() => handleButtonClick("Ranking")}>
            Ranking
          </button>
        </>)}
    </div>
  );
};

export default App;
